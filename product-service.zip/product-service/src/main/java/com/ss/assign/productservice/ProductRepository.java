package com.ss.assign.productservice;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Integer> {
    List<Product> findByProductname(String productname);
    List<Product> removeByProductname(String productname);

}