package com.ss.assign.productservice;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.transaction.Transactional;

@SpringBootApplication
@RestController
public class ProductServiceApplication {

	@Autowired
	private ProductRepository productRepository;

	@RequestMapping(path = "/addProduct")
	public @ResponseBody String addNewProduct (@RequestParam String productname, @RequestParam String description, @RequestParam String price) {
			
		if (StringUtils.hasText(productname)){
			if(productRepository.findByProductname(productname).isEmpty()){	
				Product product = new Product();
				product.setProductname(productname);
				product.setDescription(description);
				product.setPrice(price);
				productRepository.save(product);
				return "saved";
			}
			else{
				return "product already exists";
			}
		}
		else{
			return "invalid input";
		}		
	}
		
	@RequestMapping(path = "/getProductByName")
	public @ResponseBody Iterable<Product> getProductByName (@RequestParam String productname) {
		ArrayList<Product> productList = (ArrayList<Product>) productRepository.findByProductname(productname);
		return productList;
	}

	@RequestMapping(path = "/getAllProducts")
	public @ResponseBody Iterable<Product> getAllProducts () {
		ArrayList<Product> productList = (ArrayList<Product>) productRepository.findAll();
		return productList;
	}

	@RequestMapping(path = "/removeProductByName")
	@Transactional
	public @ResponseBody Iterable<Product> removeProductByName (@RequestParam String productname) {
		ArrayList<Product> productList = (ArrayList<Product>) productRepository.removeByProductname(productname);
		return productList;
	}

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}

}
