package com.ss.assign.orderservice;

import java.time.LocalDateTime;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.transaction.Transactional;

@SpringBootApplication
@RestController
public class OrderServiceApplication {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private OrderRepository orderRepository;

	@RequestMapping(path = "/addOrder")
	public @ResponseBody String addNewOrder (@RequestParam String username, @RequestParam String password, @RequestParam String productname) {
		
		if (StringUtils.hasText(username))
			{
				ArrayList<User> user = (ArrayList<User>) userRepository.findByUsername(username);
				if(user.isEmpty()){	
					return "user does not exist";
				}
				else{
					if(user.get(0).getPassword().matches(password))
					{
					  ArrayList<Product> product = (ArrayList<Product>) productRepository.findByProductname(productname);
					  if(product.size() == 0 )
					  {
						return "selected product does not exist";
					  }
					  Order order = new Order();
					  order.setUser_id(user.get(0).getUser_id());
					  order.setProduct_id(product.get(0).getProduct_id());
					  order.setTimestamp(LocalDateTime.now().toString());
					  orderRepository.save(order);
					  return "order placed";
					}
					else {
						return "invalid password supplied, cannot place order";

					}
				}
			}
			else{
				return "invalid input";
			}	
	
	}

	@RequestMapping(path = "/getAllOrders")
	public @ResponseBody Iterable<Order> getAllOrders () {
		ArrayList<Order> orderList = (ArrayList<Order>) orderRepository.findAll();
		return orderList;
	}

	@RequestMapping(path = "/removeOrderByID")
	@Transactional
	public @ResponseBody String removeUserByID (@RequestParam String order_id) {
		orderRepository.deleteById(Integer.parseInt(order_id));
		return "order deleted";
	}

	public static void main(String[] args) {
		SpringApplication.run(OrderServiceApplication.class, args);
	}

}
