package com.ss.assign.userservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import jakarta.transaction.Transactional;

@SpringBootApplication
@RestController
public class UserServiceApplication {

	@Autowired
	private UserRepository userRepository;

	@RequestMapping(path = "/addUser")
	public @ResponseBody String addNewUser (@RequestParam String username, @RequestParam String email, @RequestParam String password) {
			
			if (StringUtils.hasText(username))
			{
				if(userRepository.findByUsername(username).isEmpty()){	
					User user = new User();
					user.setUsername(username);
					user.setEmail(email);
					user.setPassword(password);
					userRepository.save(user);
					return "saved";
				}
				else{
					return "user already exists";
				}
			}
			else{
				return "invalid input";
			}		
	}
		
			@RequestMapping(path = "/getUserByName")
			public @ResponseBody Iterable<User> getUserByName (@RequestParam String username) {
			ArrayList<User> userList = (ArrayList<User>) userRepository.findByUsername(username);
			return userList;
			}

			@RequestMapping(path = "/getAllUsers")
			public @ResponseBody Iterable<User> getAllUsers () {
			ArrayList<User> userList = (ArrayList<User>) userRepository.findAll();
			return userList;
			}

			@RequestMapping(path = "/removeUserByName")
			@Transactional
			public @ResponseBody Iterable<User> removeUserByName (@RequestParam String username) {
			ArrayList<User> userList = (ArrayList<User>) userRepository.removeByUsername(username);
			return userList;
			}

			public static void main(String[] args) {
				SpringApplication.run(UserServiceApplication.class, args);
			}

		}
